import React from 'react';
import { Link } from 'react-router';

const Footer = (props) => {
    return (
        <footer className="clearfix">
            加载更多...
        </footer>
    )
};

export default Footer;